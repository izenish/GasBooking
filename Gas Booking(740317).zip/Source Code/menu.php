 <div class="menu">
                                    <ul>
                                       
                                          <li> <a class="active" href="#"><i class="fa fa-fw fa-home"></i> Home</a> </li>
        <li><a href="#"><i class="fab fa-hotjar"></i> Book Online</a> </li>
        <li><a href="#"><i class="fas fa-truck-pickup"></i> Track My Gas</a> </li>
       <li> <a href="#"><i class="fas fa-building"></i>Nearby Dealerships</a></li>
       <li> <a href="#"><i class="fas fa-address-card"></i></i>About Us</a></li>
        <li><a href="#"><i class="fas fa-user-ninja"></i>Contact Us</a> </li> 
        <li><a href="http://localhost/fosp/website/login/add_user.php"><i class="fas fa-sign-in-alt"></i>Login</a></li>
                                    </ul>
                              </div>