 
            <div id="footer">
                  <div id="shortcutfooter"><ul>
                        <li>Home</li>
                        <li>Book Online</li>
                        <li>Track My Gas</li>
                        <li>Nearby Dealership</li>
                        <li>About us</li>
                        <li>Contact us</li>
                  </ul></div>
                  <div id="about"><H2>Gas Sakyo?</h2><br><p><u>Khwopa Engineering College</u><br>740317<br>zenish77@gmail.com</p></div>
                        <div id="copyright"><hr>    Copyright © 2019 GasSakyo?. All Rights Reserved. </div>

            </div>
