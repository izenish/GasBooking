	<!DOCTYPE html>
	<html>
	<head>
		<title>Contact US!</title>
		<link rel="stylesheet" href="css/style.css">
		<link href="//db.onlinewebfonts.com/c/96a7545dadbaf8e1d3abd46eb2396823?family=LTCSquareFaceW00-SC" rel="stylesheet" type="text/css"/>

            <link rel="stylesheet" type="text/css" href="css/style1.css">
		<link rel="stylesheet" type="text/css" href="css/stylefornotindex.css">
		<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/font-awesome.min.css">
		
		<style type="text/css">
			@import url(//db.onlinewebfonts.com/c/96a7545dadbaf8e1d3abd46eb2396823?family=LTCSquareFaceW00-SC);
			#container{
				position: relative;
  text-align: center;
  color: white;
  margin-top: 1%;
			}


			#center{
				font-family:LTCSquareFaceW00-SC;
				  position: absolute;
				  font-size: 30px;
				  color:#fff200;

  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
			}
				 
		</style>
	</head>

	<body >
		<?php include('include/headerfornotindex.php');?>

	<div class="navbar">
	  <a  href="index.php"><i class="fa fa-fw fa-home"></i> Home</a> 
	  <a href="products.php"><i class="fab fa-product-hunt"></i> Products</a> 
	  <a href="beforelogin.php"><i class="fab fa-hotjar"></i> Book Online</a> 
	  
	  <a href="#"><i class="fas fa-building"></i>Nearby Dealerships</a>
	  <a href="aboutus.php" ><i class="fas fa-address-card"></i></i>About Us</a>
	  <a href="contactus.php" class="active"><i class="fas fa-user-ninja"></i>Contact Us</a>    
	    <a href="loginpage.php"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-sign-in-alt"></i>Login</a>
	</div>
	<div id="wrapper">
		<div id="container"><img src="images/contact.jpg"></div>
		<div id="center">CONTACT US<br><p>
While we're good with smoke signals, there are simpler ways for us to get in touch and answer your questions.</p></div>
	</div>
	<?php include('include/foot.php');?>




			

	</body>
	</html>