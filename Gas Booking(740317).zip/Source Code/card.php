
                  <div class="container">
                        <div class="card">
                              <div class="face face1">
                                    <div class="content">
                                          <img src="images/sale.png" class="pop">
                                          <h3>Sale</h3>
                              </div>
                        </div>
                        <div class="face face2">
                              <div class="content">
                                    <p>Check our latest sales and offers. Grab exciting gift hampers as well as some hefty discounts.
             </p>
                                    <a href="#">Read more</a>
                              </div>
                        </div>
                  </div>
                  <div class="card">
                              <div class="face face1">
                                    <div class="content">
                                          <img src="images/review.png" class="pop">
                                          <h3>Review</h3>
                              </div>
                        </div>
                        <div class="face face2">
                              <div class="content">
                                    <p>Check our reviews from some of our loyal customers who we adore and totaly respect.
             </p>
                                    <a href="#">Read more</a>
                              </div>
                        </div>
                  </div>
                  <div class="card">
                              <div class="face face1">
                                    <div class="content">
                                          <img src="images/support.png" class="pop">
                                          <h3>Support</h3>
                              </div>
                        </div>
                        <div class="face face2">
                              <div class="content">
                                    <p>Having issues?
                                          Let us help you.
             </p>
                                    <a href="#">Read more</a>
                              </div>
                        </div>
                  </div>



                  </div>
                  </div>